/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package java_prog5121_poe;
import java.util.Scanner;
/**
 *
 * @author RC_Student_lab
 */
public class Java_Prog5121_Poe {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args){
        Scanner input = new Scanner (System.in);
        while (true){
            
            System.out.println("\n1.Register\n2.login\n3.exit");
            System.out.println("choose option");
            int choice = input.nextInt();
            switch(choice){
            case 1:
          register();
            break;
            case 2:
            login();
            break;
            case 3:
            System.out.println("Goodbye....");
            break;
            default:
            System.out.println("invalid option.Please try again");
          
            }
            
            
        }
            
        }
    private static void register(){
        System.out.print("Enter username");
        String username = input.nextLIne();
        
        if(username.matches("^(?=.*_).{1,5}$")){
            System.out.println("username successfully captured.");}
        else {
            System.out.println("username is not correctly formatted,"
            + "please ensure that your username contains an underscore"
            + "and is no more than five characters in length");
            return;}
            //prompt password
            System.out.print("Enter password:");
            String password = input.nextLine();
            
            if(password.matches("^(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$%^&*]).{8,}$")){
                System.out.println("password successfully captured.");
            }
            else{
               System.out.println("Passsword is not correctly formatted,"
               + "please ensure that the password contains at least"
               + "eight characters, a capital letter,"
               + "a number, and a special characters.");
               return;}
               
               //prompt cellphonenumber
               System.out.print("Enter cellphonenumber ");
               String cellphonenumber = input.nextLine();
               
               if(cellphonenumber.matches("\\+27\\.d{9}"))
            System.out.println("cell phone number successfully added.");
               
            else
                   System.out.println("cell phone number incorrectly formatted,"
                   + "or does not contain international code");
               
               
               
            return;
            
        }
    private static void logic(){
        System.out.print("Enter username");
        String username = input.nextLIne();
        
         if(username.matches("is correct")){
            System.out.println("welcome its great to see you again.");}
        else {
            System.out.println("username is not correctly formatted,"
            + "please ensure that your username contains an underscore"
            + "and is no more than five characters in length");
            return;}
         
        //prompt password
        System.out.print("Enter password:");
            String password = input.nextLine();
            
            
        if(password.matches("is correct")){
                System.out.println("welcome its great to see you again.");
                
              }
            else{
               System.out.println("Passsword is not correctly formatted,"
               + "please ensure that the password contains at least"
               + "eight characters, a capital letter,"
               + "a number, and a special characters.");
               return;}   
   
               
               
               
               
            
        // TODO code application logic here
    }

    private static void login() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}
