/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package java_prog5121_poe;
import java.util.Scanner;
/**
 *
 * @author RC_Student_lab
 */
public class LOGIN {
    
    
}
